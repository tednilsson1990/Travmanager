import { render } from "preact";
import { html } from "htm/preact";
import App from "./ui/App.js";

render(html`<${App} />`, document.getElementById("root"));
